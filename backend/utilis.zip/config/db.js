import mongoose from "mongoose";
const MONGO_DB="mongodb+srv://maryamzahid960:maryam@cluster0.jvd3wpy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

const db = async () => {
    try {
        console.log("⏳ Connecting to MongoDB...");
        await mongoose.connect(MONGO_DB, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log("✅ MongoDB Connected Successfully");
    } catch (error) {
        console.error("❌ MongoDB Connection Error:", error.message);
        process.exit(1);
    }
};

export default db;
