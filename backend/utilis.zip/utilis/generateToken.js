import jwt from 'jsonwebtoken'
const NODE_ENV="development"
const SECRET_KEY="MARYAM123"

const generateToken= ((res,UserId)=>{
    const token=jwt.sign({UserId},SECRET_KEY,{expiresIn : '30d'})
    res.cookie('jwt',token,{
        httpOnly:true,
        Secure : NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 30 * 24 * 60 *60 *1000
    })

})

export default generateToken;